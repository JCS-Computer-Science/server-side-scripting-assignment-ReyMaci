//Do not modify this file
const app = require("./server");
// const app = require("./solution");

app.listen(5500, () => console.log("listening on port 5500"));

